package minegame159.meteorclient.mixininterface;

import net.minecraft.text.Text;

public interface IChatHud {
    void add(Text message, int messageId);
}
