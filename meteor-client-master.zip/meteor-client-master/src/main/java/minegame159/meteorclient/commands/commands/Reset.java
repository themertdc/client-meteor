/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client/).
 * Copyright (c) 2020 Meteor Development.
 */

package minegame159.meteorclient.commands.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import minegame159.meteorclient.Config;
import minegame159.meteorclient.commands.Command;
import minegame159.meteorclient.commands.arguments.ModuleArgumentType;
import minegame159.meteorclient.modules.Module;
import minegame159.meteorclient.modules.ModuleManager;
import minegame159.meteorclient.settings.Setting;
import minegame159.meteorclient.utils.player.Chat;
import net.minecraft.command.CommandSource;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class Reset extends Command {

    public Reset() {
        super("reset", "Resets specified settings.");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("settings")
                .then(argument("module", ModuleArgumentType.module()).executes(context -> {
                    Module module = context.getArgument("module", Module.class);
                    module.settings.forEach(group -> group.forEach(Setting::reset));
                    return SINGLE_SUCCESS;
                }))
                .then(literal("all").executes(context -> {
                    ModuleManager.INSTANCE.getAll().forEach(module -> module.settings.forEach(group -> group.forEach(Setting::reset)));
                    return SINGLE_SUCCESS;
                }))
        ).then(literal("gui").executes(context -> {
            Config.INSTANCE.guiConfig.clearWindowConfigs();
            Chat.info("The ClickGUI positioning has been reset.");
            return SINGLE_SUCCESS;
        })).then(literal("bind")
                .then(argument("module", ModuleArgumentType.module()).executes(context -> {
                    Module module = context.getArgument("module", Module.class);

                    module.setKey(-1);
                    Chat.info("This bind has been reset.");

                    return SINGLE_SUCCESS;
                }))
                .then(literal("all").executes(context -> {
                    ModuleManager.INSTANCE.getAll().forEach(module -> module.setKey(-1));
                    return SINGLE_SUCCESS;
                }))
        );
    }
}
