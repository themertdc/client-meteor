package minegame159.meteorclient.events.packets;

import net.minecraft.network.Packet;

public class PacketSentEvent {
    public Packet<?> packet;
}
