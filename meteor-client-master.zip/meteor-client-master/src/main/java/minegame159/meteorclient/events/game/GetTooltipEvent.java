package minegame159.meteorclient.events.game;

import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

import java.util.List;

public class GetTooltipEvent {
    public ItemStack itemStack;
    public List<Text> list;
}
