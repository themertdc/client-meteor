package minegame159.meteorclient.events.world;

public class ConnectToServerEvent {
}
