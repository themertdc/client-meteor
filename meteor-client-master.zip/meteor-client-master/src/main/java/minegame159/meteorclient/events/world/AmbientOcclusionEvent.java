package minegame159.meteorclient.events.world;

public class AmbientOcclusionEvent {
    public float lightLevel = -1;
}
