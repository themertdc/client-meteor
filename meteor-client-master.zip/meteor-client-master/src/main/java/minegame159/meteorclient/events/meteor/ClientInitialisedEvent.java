package minegame159.meteorclient.events.meteor;

public class ClientInitialisedEvent {
}
