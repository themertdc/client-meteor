package minegame159.meteorclient.events.world;

import minegame159.meteorclient.events.Cancellable;

public class ChunkOcclusionEvent extends Cancellable {
}
