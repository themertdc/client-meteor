package minegame159.meteorclient.rendering;

public enum ShapeMode {
    Lines,
    Sides,
    Both
}
